﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Train_calculations
{
    public enum Cargo_types
    {
        normal_cargo = 0,
        nonSolid_cargo = 150,
        dangerous_cargo = 300,
    }

    class Freight : Trains_core
    {
        public Cargo_types Cargo_type;
        internal static readonly int cost = 300;
        internal static readonly int base_revenue = 550;
        internal int revenue = 0;

        public Freight(int serial_number, int production_year, Cargo_types cargo_type) : base(serial_number, production_year)
        {
            Cargo_type = cargo_type;
        }

        int setRevenue()
        {
            return (int)(base_revenue + Cargo_type);
        }

        public override double GetProfit() 
        {
            return (setRevenue() - cost);
        }
    }
}
