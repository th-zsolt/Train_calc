﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Train_calculations
{
    class IC : Passanger
    {
        static new readonly int cost = 1200;
        internal static readonly int maxCoaches = 10;
        static new readonly double seat_fare = 0.5;

        public IC(int coaches, int serial_number, int production_year) : base(coaches, serial_number, production_year)
        {
        }

        public new int Coaches
        {
            set
            {
                if (Coaches > 10)
                {
                    throw new Exception("Coaches number of IC cannot be greater than 10");
                }
                else if (Coaches > 0)
                {
                    this.Coaches = Coaches;
                }
                else
                {
                    throw new Exception("Coaches number cannot be negative");
                }
            }

            get
            {
                return this.Coaches;
            }
        }
    }
}
