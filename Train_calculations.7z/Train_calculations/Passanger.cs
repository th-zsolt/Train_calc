﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Train_calculations
{
    class Passanger : Trains_core
    {
        internal static readonly int cost = 1000;
        internal static readonly double ticket_price = 1.5;
        internal static readonly double ticket_OnTrain_addPrice = 2;
        internal static readonly double ticket_OnTrain_percent = 0.25;
        internal static readonly int daily_passangerNumber_perCoach = 50;
        internal static readonly double seat_fare = 0;

        public int Coaches = 0;

        public Passanger(int coaches, int serial_number, int production_year) : base(serial_number, production_year)
        {
            Coaches = coaches;
        }

        public override double GetProfit()
        {
            if (Coaches != 0)
            {
                return ((Coaches * daily_passangerNumber_perCoach * ((ticket_price + ((1 + ticket_OnTrain_percent) * ticket_OnTrain_addPrice)))+seat_fare) - cost);
            }
            else
            {
                throw new Exception("Coaches number cannot be zero");
            }
        }
    }
}
