﻿using System;

namespace Train_calculations
{
    class Program
    {
        static void Main(string[] args)
        {

            IC[] Trains_IC = new IC[]
            {
            new IC (8, 001, 1970),
            new IC (3, 002, 1982),
            };

            Passanger[] Trains_passanger = new Passanger[]
            {
            new Passanger (12, 003, 2000),
            new Passanger (12, 003, 2000),
            };

            Freight[] Trains_freight = new Freight[]
            {
            new Freight (101, 1988, Cargo_types.normal_cargo),
            new Freight (102, 2008, Cargo_types.dangerous_cargo),
            new Freight (103, 2013, Cargo_types.dangerous_cargo),
            };

            double totalProfit = 0;
            Array.ForEach (Trains_freight, train => totalProfit = totalProfit + train.GetProfit() );
            Array.ForEach(Trains_IC, train => totalProfit = totalProfit + train.GetProfit());
            Array.ForEach(Trains_passanger, train => totalProfit = totalProfit + train.GetProfit());

            Console.WriteLine("Total profit: " + totalProfit);
            Console.WriteLine("Freight trains that transport dangerous cargo:");
            Array.ForEach(Trains_freight, train =>
            {
                if (train.Cargo_type == Cargo_types.dangerous_cargo)
                {
                    Console.WriteLine(train.Serial_number);
                }
            });
        }
    }
}
