﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Train_calculations
{
    abstract class Trains_core
    {
        public int Serial_number;
        public int Production_year;

        public Trains_core(int serial_number, int production_year)
        {
           Serial_number = serial_number;
           Production_year = production_year;
        }

        public abstract double GetProfit();
    }
}
